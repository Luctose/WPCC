"""
Lucas Sarweh
110042658
Date: 27 Dec 2020
"""

# Main function
def main():
    # Get user input and reverse it
    userInput = input("Please enter a string: ")[::-1]
    
    # Print the string
    print(userInput)

# Thingy
if __name__ == "__main__":
    main()